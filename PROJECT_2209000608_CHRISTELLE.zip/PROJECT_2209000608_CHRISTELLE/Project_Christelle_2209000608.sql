show databases;
create database Jail_management_system;
use Jail_management_system;
/* Description of my project:The Jail Management System is a software application designed to manage and maintain information about prisoners, jail staff, and related administrative tasks. 
This system aims to track prisoner details (such as personal information, crime committed, sentence length), manage jail staff schedules, and monitor inmate activities within the jail.
 Additionally, it provides functionalities for reports, visitor tracking, and maintaining the overall security operations of the jail.*/
 create table Prisoners(
 PrisonerID INT PRIMARY KEY auto_increment, 
    FirstName VARCHAR(50) NOT NULL, 
    LastName VARCHAR(50) NOT NULL, 
    DOB DATE NOT NULL, 
    Gender varchar(10),
    Crime varchar(50)
    );
create table Staffs(
 Staff_ID INT Primary key AUTO_INCREMENT,
First_Name VARCHAR(50),
Last_Name VARCHAR(50),
Position VARCHAR(50),
Department VARCHAR(50)
);
create table Visitations(
	Visit_ID INT primary key AUTO_INCREMENT,
    Visitor_Name VARCHAR(100),
    Visit_Date DATE,
	Duration TIME,
    Prisoner_ID INT, 
   Foreign key (Prisoner_ID) references Prisoners(Prisoner_ID)
   );
   create table Cells(
   Cell_ID INT primary key AUTO_INCREMENT,
   Cell_Number int,
   Capacity int,
   Prisoner_ID int,
   Foreign key (Prisoner_ID)references Prisoners(Prisoner_ID)
);
create table Activities(
    Activity_ID INT Primary Key AUTO_INCREMENT,
    Activity_type Varchar(50), 
    Activity_Date Date,
    Prisoner_ID INT, 
   Foreign key (Prisoner_ID )references Prisoners(Prisoner_ID)
   );
   create table Reports(
  Report_ID INT Primary Key AUTO_INCREMENT, 
  Report_Date Date,
   Report_content Varchar(50),
   Staff_ID INT, 
  Foreign key( Staff_ID )references Staffs(Staff_ID)
  );
  -- INSERTING IN EACH TABLE
  insert into Prisoners (Prisoner_ID,First_Name,Last_Name,DOB,Gender,Crime)
  Values(001,'Michael','John','2002-01-02','M','Murder'),
        (002,'Jane','Marry','2003-09-08','F','Steal');
insert into Staffs(Staff_ID,First_Name,Last_Name,Position,Department)
values(1,'Jean','Jacques','Director','Medical'),
      (2,'Michel','Georges','Commisar','Security');
insert into Visitations(Visit_ID,Prisoner_ID,Visitor_Name,Visit_Date,Duration )
values(1,001,'Luc Axel','2025-01-01',2hours),
      (2,002,'Mael Smith','2025-02-03',4hours);
insert into Cells(Cell_ID,Prisoner_ID,Cell_Number,Capacity)
    values  (001,001,22,3000),
      (002,002,33,4000);
insert into Activities(Activity_ID,Prisoner_ID,Activity_Type,Activity_date)
	values(1,001,'Prison Labour','2024-04-05'),
          (2,002,'Yoga','2025-09-01');
insert into Reports(Report_ID,Staff_Id,Report_Date,Report_Content)
values(1,1,'2023-06-03','Monthly verify behaviour'),
      (2,2,'2024-01-03','Verified activity by week');
      -- Select in each table
      SELECT * FROM Prisoners;
      SELECT * FROM Prisoners WHERE Prisoner_ID = 001;
      SELECT * FROM Visitations WHERE Visit_ID = 2;
      SELECT * FROM Staffs WHERE Position = 'Commisar';
      SELECT Prisoners.Name AS PrisonerName, Staffs.Name AS StaffName
FROM Prisoners
JOIN Staffs ON Prisoners.AssignedStaffID = Staffs.StaffID;
select *FROM Cells where capacity='4000';
select*from Activities where Prisoner_ID=001;
select*from Reports where Report_Date='2023-06-03';

-- UPDATING IN EACH TABLE
UPDATE Prisoners
SET FirstName = 'Jane', LastName = 'Doe'
WHERE Prisoner_ID = 001;
UPDATE Staffs
SET Position = 'Supervisor'
WHERE Staff_ID = 1;
UPDATE Visitations
SET Duration= '11:00:00'
WHERE Visit_ID = 1;
UPDATE Cells
SET Capacity = 3
WHERE Cell_ID = 011;
UPDATE Activities
SET Activity_Type = 'Sport'
WHERE Activity_ID = 1;
UPDATE Reports
SET Content = 'Updated content of the monthly report.'
WHERE Report_ID = 1;
-- DELETE IN EACH TABLE
DELETE FROM Prisoners WHERE Prisoner_ID = 001;
DELETE FROM Visitations WHERE PrisonerI_D = 001;
DELETE FROM Staffs WHERE StaffID = 1;
DELETE FROM Cells WHERE Cell_Number= 22;
DELETE FROM Activities WHERE Activity_type = 'yoga';
DELETE FROM Reports WHERE Report_ID = 1;
-- ALTER
ALTER TABLE Prisoners
ADD Nationality VARCHAR(50);
ALTER TABLE Staffs
ADD Salary DECIMAL(12, 2);
ALTER TABLE Visitations
ADD VisitPurpose VARCHAR(100);
ALTER TABLE Cells
RENAME COLUMN Floor TO CellFloor;
ALTER TABLE Activities
ADD StartTime TIME NOT NULL;
ALTER TABLE Reorts
Add StartTime TIME NOT NULL;
-- Count
-- Count the total number of prisoners:
SELECT COUNT(*) AS TotalPrisoners FROM Prisoners;
-- Count the total number of staff members:
SELECT COUNT(*) AS TotalStaff FROM Staffs;
-- Count how many visitations each prisoner has had:
SELECT Prisoner_ID, COUNT(*) AS TotalVisitations
FROM Visitations
GROUP BY Prisoner_ID;
-- Count how many cells are currently occupied:
SELECT COUNT(*) AS OccupiedCells FROM Cells WHERE Occupied > 0;
-- Count the total number of activities for a prisoner 
SELECT COUNT(*) AS TotalActivities
FROM Activities
WHERE Prisoner_ID = 002;
-- count the total number of report per month
select count(*)as TotalNumber
from Reports
where Report_ID=1;
-- AVG queries
-- Calculate the average sentence length of prisoners:
SELECT AVG(SentenceLength) AS AverageSentenceLength FROM Prisoners;
-- Calculate the average salary of staff:
SELECT AVG(Salary) AS AverageSalary FROM Staffs;
-- Calculate the average duration of visitations:
SELECT AVG(VisitDuration) AS AverageVisitDuration FROM Visitations;
-- Calculate the average occupancy per cell:
SELECT AVG(Occupied) AS AverageOccupancy FROM Cells;
-- Calculate the average duration of activities for prisoners:
SELECT AVG(TIMESTAMPDIFF(MINUTE, StartTime, EndTime)) AS AverageActivityDuration
FROM Activities;
-- calculate the average report time
select avg(time) as Report_time 
from Reports;
-- Sum queries
-- Sum of all prisoners' sentence lengths:
SELECT SUM(SentenceLength) AS TotalSentenceLength FROM Prisoners;
-- Sum of all staff salaries:
SELECT SUM(Salary) AS TotalSalaries FROM Staffs;
-- Sum of all visitation durations:
SELECT SUM(VisitDuration) AS TotalVisitDuration FROM Visitations;
-- Sum of the total occupancy in all cells:
SELECT SUM(Occupied) AS TotalOccupied FROM Cells;
-- Sum of activity durations for a specific prisoner 
SELECT SUM(TIMESTAMPDIFF(MINUTE, StartTime, EndTime)) AS TotalActivityDuration
FROM Activities
WHERE Prisoner_ID =002;
SELECT SUM(Prisoners.SentenceLength) AS TotalReportedSentenceLength
FROM Reports
JOIN Prisoners ON Reports.PrisonerID = Prisoners.PrisonerID;
-- Views (Six Different):
-- View for Prisoner and Assigned Staff:
CREATE VIEW PrisonerStaffView AS
SELECT Prisoners.Name AS PrisonerName, Staffs.Name AS StaffName
FROM Prisoners
JOIN Staffs ON Prisoners.AssignedStaffID = Staffs.StaffID;
-- View for Activities and Staff:
CREATE VIEW ActivityStaffView AS
SELECT Activities.ActivityType, Staffs.Name AS StaffName
FROM Activities
JOIN Staffs ON Activities.StaffID = Staffs.StaffID;
-- View for Visitations
CREATE VIEW VisitationsView AS
SELECT Prisoners.Name AS PrisonerName, Visitations.VisitorName, Visitations.VisitDate
FROM Visitations
JOIN Prisoners ON Visitations.PrisonerID = Prisoners.PrisonerID;
-- View for Cell Occupancy:
CREATE VIEW CellOccupancyView AS
SELECT Cells.CellType, Cells.Occupied, Cells.Capacity
FROM Cells;
-- View for Prisoners with Activities
CREATE VIEW PrisonerActivitiesView AS
SELECT Prisoners.Name AS PrisonerName, Activities.ActivityType, Activities.StartTime, Activities.EndTime
FROM Prisoners
JOIN Activities ON Prisoners.PrisonerID = Activities.PrisonerID;
-- View for Reports by Staff:
CREATE VIEW StaffReportsView AS
SELECT Reports.ReportDate, Staffs.Name AS StaffName, Reports.ReportDetails
FROM Reports
JOIN Staffs ON Reports.StaffID = Staffs.StaffID;
-- Stored Procedures (Six Examples):
-- Add New Prisoner:
CREATE PROCEDURE AddPrisoner(p_Name VARCHAR, p_Age INT, p_Gender VARCHAR, p_SentenceLength INT, p_CellID INT, p_StaffID INT)
AS
BEGIN
  INSERT INTO Prisoners (Name, Age, Gender, SentenceLength, AssignedCellID, AssignedStaffID)
  VALUES (p_Name, p_Age, p_Gender, p_SentenceLength, p_CellID, p_StaffID);
END;
-- Update Prisoner’s Sentence:
CREATE PROCEDURE UpdatePrisonerSentence(p_PrisonerID INT, p_SentenceLength INT)
AS
BEGIN
  UPDATE Prisoners
  SET SentenceLength = p_SentenceLength
  WHERE PrisonerID = p_PrisonerID;
END;
-- Delete Prisoner:
CREATE PROCEDURE DeletePrisoner(p_PrisonerID INT)
AS
BEGIN
  DELETE FROM Prisoners WHERE PrisonerID = p_PrisonerID;
END;
-- Assign Staff to Prisoner:
CREATE PROCEDURE AssignStaffToPrisoner(p_PrisonerID INT, p_StaffID INT)
AS
BEGIN
  UPDATE Prisoners
  SET AssignedStaffID = p_StaffID
  WHERE PrisonerID = p_PrisonerID;
END;
-- Generate Report:
CREATE PROCEDURE GenerateReport(p_ReportDetails TEXT, p_StaffID INT, p_PrisonerID INT)
AS
BEGIN
  INSERT INTO Reports (ReportDate, ReportDetails, StaffID, PrisonerID)
  VALUES (SYSDATE, p_ReportDetails, p_StaffID, p_PrisonerID);
END;
-- Get Prisoner Activities:
CREATE PROCEDURE GetPrisonerActivities(p_PrisonerID INT)
AS
BEGIN
  SELECT ActivityType, StartTime, EndTime
  FROM Activities
  WHERE PrisonerID = p_PrisonerID;
END;
-- Triggers (After UID for Each Table):
-- After Insert on Prisoners Table:
CREATE TRIGGER AfterPrisonerInsert
AFTER INSERT ON Prisoners
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('New prisoner added: ' || :NEW.Name);
END;
-- After Update on Staff Table:
CREATE TRIGGER AfterStaffUpdate
AFTER UPDATE ON Staffs
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('Staff updated: ' || :NEW.Name);
END;
-- After Delete on Visitations Table:
CREATE TRIGGER AfterVisitDeletion
AFTER DELETE ON Visitations
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('Visit deleted for prisoner: ' || :OLD.PrisonerID);
END;
-- After Insert on Activities Table:
CREATE TRIGGER AfterActivityInsert
AFTER INSERT ON Activities
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('New activity added for prisoner: ' || :NEW.PrisonerID);
END;
-- After Insert on Cells Table:
CREATE TRIGGER AfterCellInsert
AFTER INSERT ON Cells
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('New cell added: ' || :NEW.CellID);
END;
-- After Insert on Reports Table:
CREATE TRIGGER AfterReportInsert
AFTER INSERT ON Reports
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('New report generated for prisoner: ' || :NEW.PrisonerID);
END;












